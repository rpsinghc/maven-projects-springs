package com.worldcheck.atlas.vo.masters;

public class LeaveTypeMasterVO {
	private String leaveTypeMasterId;
	private String description;
	private String updatedBy;
	private String updatedOn;

	public String getLeaveTypeMasterId() {
		return this.leaveTypeMasterId;
	}

	public void setLeaveTypeMasterId(String leaveTypeMasterId) {
		this.leaveTypeMasterId = leaveTypeMasterId;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getUpdatedOn() {
		return this.updatedOn;
	}

	public void setUpdatedOn(String updatedOn) {
		this.updatedOn = updatedOn;
	}
}
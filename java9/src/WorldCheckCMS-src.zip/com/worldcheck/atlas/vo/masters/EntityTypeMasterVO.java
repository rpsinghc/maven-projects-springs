package com.worldcheck.atlas.vo.masters;

public class EntityTypeMasterVO {
	private String entityType;
	private String entityTypeID;

	public String getEntityType() {
		return this.entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getEntityTypeID() {
		return this.entityTypeID;
	}

	public void setEntityTypeID(String entityTypeID) {
		this.entityTypeID = entityTypeID;
	}
}
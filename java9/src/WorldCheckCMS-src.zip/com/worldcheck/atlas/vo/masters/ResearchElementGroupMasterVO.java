package com.worldcheck.atlas.vo.masters;

public class ResearchElementGroupMasterVO {
	private String reGroupval;
	private String reCodeval;
	private String rePointsval;
	private String reNameval;
	private String reSubVenTeam;
	private String reBITeam;
	private String rElementId;
	private String reEntityTypeIdval;
	private String reStatusval;
	private String reGroupId;
	private String reRemEng;

	public String getReStatusval() {
		return this.reStatusval;
	}

	public void setReStatusval(String reStatusval) {
		this.reStatusval = reStatusval;
	}

	public String getReEntityTypeIdval() {
		return this.reEntityTypeIdval;
	}

	public void setReEntityTypeIdval(String reEntityTypeIdval) {
		this.reEntityTypeIdval = reEntityTypeIdval;
	}

	public String getrElementId() {
		return this.rElementId;
	}

	public void setrElementId(String rElementId) {
		this.rElementId = rElementId;
	}

	public String getReGroupval() {
		return this.reGroupval;
	}

	public void setReGroupval(String reGroupval) {
		this.reGroupval = reGroupval;
	}

	public String getReCodeval() {
		return this.reCodeval;
	}

	public void setReCodeval(String reCodeval) {
		this.reCodeval = reCodeval;
	}

	public String getRePointsval() {
		return this.rePointsval;
	}

	public void setRePointsval(String rePointsval) {
		this.rePointsval = rePointsval;
	}

	public String getReNameval() {
		return this.reNameval;
	}

	public void setReNameval(String reNameval) {
		this.reNameval = reNameval;
	}

	public String getReSubVenTeam() {
		return this.reSubVenTeam;
	}

	public void setReSubVenTeam(String reSubVenTeam) {
		this.reSubVenTeam = reSubVenTeam;
	}

	public String getReBITeam() {
		return this.reBITeam;
	}

	public void setReBITeam(String reBITeam) {
		this.reBITeam = reBITeam;
	}

	public String getReGroupId() {
		return this.reGroupId;
	}

	public void setReGroupId(String reGroupId) {
		this.reGroupId = reGroupId;
	}

	public String getReRemEng() {
		return this.reRemEng;
	}

	public void setReRemEng(String reRemEng) {
		this.reRemEng = reRemEng;
	}
}
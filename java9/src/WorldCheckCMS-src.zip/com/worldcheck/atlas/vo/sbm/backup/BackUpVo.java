package com.worldcheck.atlas.vo.sbm.backup;

public class BackUpVo {
	private String userId;

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
}
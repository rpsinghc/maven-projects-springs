package com.worldcheck.atlas.vo.report;

public class JLPAndOfficeSummaryVO {
	private String office;
	private float cmpPoints;
	private float wipPoints;
	private String month;

	public String getOffice() {
		return this.office;
	}

	public void setOffice(String office) {
		this.office = office;
	}

	public float getCmpPoints() {
		return this.cmpPoints;
	}

	public void setCmpPoints(float cmpPoints) {
		this.cmpPoints = cmpPoints;
	}

	public float getWipPoints() {
		return this.wipPoints;
	}

	public void setWipPoints(float wipPoints) {
		this.wipPoints = wipPoints;
	}

	public String getMonth() {
		return this.month;
	}

	public void setMonth(String month) {
		this.month = month;
	}
}
package com.worldcheck.atlas.vo.report;

public class OfficeSummaryVO {
	private String office;
	private float cmpPointsForMonth1;
	private float wipPointsForMonth1;
	private float ttlPointsForMonth1;
	private float avgPointsForMonth1;
	private float cmpPointsForMonth2;
	private float wipPointsForMonth2;
	private float ttlPointsForMonth2;
	private float avgPointsForMonth2;
	private float cmpPointsForMonth3;
	private float wipPointsForMonth3;
	private float ttlPointsForMonth3;
	private float avgPointsForMonth3;

	public String getOffice() {
		return this.office;
	}

	public void setOffice(String office) {
		this.office = office;
	}

	public float getCmpPointsForMonth1() {
		return this.cmpPointsForMonth1;
	}

	public void setCmpPointsForMonth1(float cmpPointsForMonth1) {
		this.cmpPointsForMonth1 = cmpPointsForMonth1;
	}

	public float getWipPointsForMonth1() {
		return this.wipPointsForMonth1;
	}

	public void setWipPointsForMonth1(float wipPointsForMonth1) {
		this.wipPointsForMonth1 = wipPointsForMonth1;
	}

	public float getTtlPointsForMonth1() {
		return this.ttlPointsForMonth1;
	}

	public void setTtlPointsForMonth1(float ttlPointsForMonth1) {
		this.ttlPointsForMonth1 = ttlPointsForMonth1;
	}

	public float getAvgPointsForMonth1() {
		return this.avgPointsForMonth1;
	}

	public void setAvgPointsForMonth1(float avgPointsForMonth1) {
		this.avgPointsForMonth1 = avgPointsForMonth1;
	}

	public float getCmpPointsForMonth2() {
		return this.cmpPointsForMonth2;
	}

	public void setCmpPointsForMonth2(float cmpPointsForMonth2) {
		this.cmpPointsForMonth2 = cmpPointsForMonth2;
	}

	public float getWipPointsForMonth2() {
		return this.wipPointsForMonth2;
	}

	public void setWipPointsForMonth2(float wipPointsForMonth2) {
		this.wipPointsForMonth2 = wipPointsForMonth2;
	}

	public float getTtlPointsForMonth2() {
		return this.ttlPointsForMonth2;
	}

	public void setTtlPointsForMonth2(float ttlPointsForMonth2) {
		this.ttlPointsForMonth2 = ttlPointsForMonth2;
	}

	public float getAvgPointsForMonth2() {
		return this.avgPointsForMonth2;
	}

	public void setAvgPointsForMonth2(float avgPointsForMonth2) {
		this.avgPointsForMonth2 = avgPointsForMonth2;
	}

	public float getCmpPointsForMonth3() {
		return this.cmpPointsForMonth3;
	}

	public void setCmpPointsForMonth3(float cmpPointsForMonth3) {
		this.cmpPointsForMonth3 = cmpPointsForMonth3;
	}

	public float getWipPointsForMonth3() {
		return this.wipPointsForMonth3;
	}

	public void setWipPointsForMonth3(float wipPointsForMonth3) {
		this.wipPointsForMonth3 = wipPointsForMonth3;
	}

	public float getTtlPointsForMonth3() {
		return this.ttlPointsForMonth3;
	}

	public void setTtlPointsForMonth3(float ttlPointsForMonth3) {
		this.ttlPointsForMonth3 = ttlPointsForMonth3;
	}

	public float getAvgPointsForMonth3() {
		return this.avgPointsForMonth3;
	}

	public void setAvgPointsForMonth3(float avgPointsForMonth3) {
		this.avgPointsForMonth3 = avgPointsForMonth3;
	}
}
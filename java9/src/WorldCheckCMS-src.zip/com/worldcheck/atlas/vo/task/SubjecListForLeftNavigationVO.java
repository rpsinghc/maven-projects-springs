package com.worldcheck.atlas.vo.task;

public class SubjecListForLeftNavigationVO {
	private String subjectName;
	private String subjectId;

	public String getSubjectName() {
		return this.subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public String getSubjectId() {
		return this.subjectId;
	}

	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}
}
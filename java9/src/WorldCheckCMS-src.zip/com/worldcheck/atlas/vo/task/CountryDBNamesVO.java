package com.worldcheck.atlas.vo.task;

public class CountryDBNamesVO {
	private String isChecked;
	private String countryDB;
	private String company;
	private String individual;

	public String getIsChecked() {
		return this.isChecked;
	}

	public void setIsChecked(String isChecked) {
		this.isChecked = isChecked;
	}

	public String getCountryDB() {
		return this.countryDB;
	}

	public void setCountryDB(String countryDB) {
		this.countryDB = countryDB;
	}

	public String getCompany() {
		return this.company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getIndividual() {
		return this.individual;
	}

	public void setIndividual(String individual) {
		this.individual = individual;
	}
}
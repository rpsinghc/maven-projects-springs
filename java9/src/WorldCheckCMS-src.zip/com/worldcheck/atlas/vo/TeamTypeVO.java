package com.worldcheck.atlas.vo;

public class TeamTypeVO {
	private String teamTypeId;
	private String teamType;

	public String getTeamTypeId() {
		return this.teamTypeId;
	}

	public void setTeamTypeId(String teamTypeId) {
		this.teamTypeId = teamTypeId;
	}

	public String getTeamType() {
		return this.teamType;
	}

	public void setTeamType(String teamType) {
		this.teamType = teamType;
	}
}
package com.worldcheck.atlas.bl.interfaces;

public interface IMessageSearchManager {
}
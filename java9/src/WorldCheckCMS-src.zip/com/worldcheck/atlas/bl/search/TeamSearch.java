package com.worldcheck.atlas.bl.search;

import com.worldcheck.atlas.bl.interfaces.ISearch;
import java.util.List;

public class TeamSearch implements ISearch {
	public List search(SearchCriteria searchCriteria) {
		return null;
	}
}
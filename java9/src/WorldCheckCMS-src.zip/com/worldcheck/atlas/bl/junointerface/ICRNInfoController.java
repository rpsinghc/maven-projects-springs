package com.worldcheck.atlas.bl.junointerface;

import com.worldcheck.atlas.vo.junointerface.CRNInfoVO;

public interface ICRNInfoController {
	CRNInfoVO getInfoForCase(String var1);
}
package com.worldcheck.atlas.cache.bl;

import net.sf.ehcache.constructs.blocking.CacheEntryFactory;

public class EhCacheEntryFactory implements CacheEntryFactory {
	public Object createEntry(Object key) throws Exception {
		return null;
	}

	public void updateEntryValue(Object key, Object value) throws Exception {
	}
}